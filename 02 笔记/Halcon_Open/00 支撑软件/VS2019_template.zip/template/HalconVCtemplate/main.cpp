#include "HalconCpp.h"
int main()
{
    using namespace HalconCpp;
    HImage Mandrill("monkey");
    Hlong width, height;
    Mandrill.GetImageSize(&width, &height);
    HWindow w(0, 0, width, height);
    Mandrill.DispImage(w); w.Click();
    w.ClearWindow();
    HRegion Bright = Mandrill >= 128;
    HRegion Conn = Bright.Connection();
    HRegion Large = Conn.SelectShape("area", "and", 500, 90000);
    HRegion Eyes = Large.SelectShape("anisometry", "and", 1, 1.7);
    Eyes.DispRegion(w);
    w.Click();
}